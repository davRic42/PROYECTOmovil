package co.edu.gestion_inventarios.api;

public interface ValuesApi {
    String BASE_URL = "http://10.57.30.155/api_clase/";
    //String BASE_URL = "http://192.168.0.14/api_clase/";
}
