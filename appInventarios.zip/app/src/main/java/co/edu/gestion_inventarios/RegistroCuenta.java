package co.edu.gestion_inventarios;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class RegistroCuenta extends AppCompatActivity {
    private Button btnRegistrarUsuario;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        begin();
        this.btnRegistrarUsuario.setOnClickListener(this::goTo);
    }
    private void goTo(View view) {
        Intent intent = new Intent(this, menu.class);
        startActivity(intent);
    }

    private void begin(){
        this.btnRegistrarUsuario = findViewById(R.id.btnRegistrarUsuario);
    }
}
