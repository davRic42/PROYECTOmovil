package co.edu.gestion_inventarios;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class activity_editarPerfil extends AppCompatActivity {
    private Button btnAtrasPerfil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_perfil);
        Begin();
        this.btnAtrasPerfil.setOnClickListener(this::irAtras);
    }

    private void irAtras(View view) {
        Intent irAtras = new Intent(getApplicationContext(), menu.class);
        startActivity(irAtras);
    }

    @SuppressLint("WrongViewCast")
    private void Begin() {
    this.btnAtrasPerfil = findViewById(R.id.ibtnAtrasPerfil);
    }
}