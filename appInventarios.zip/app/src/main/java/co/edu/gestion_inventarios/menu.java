package co.edu.gestion_inventarios;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class menu extends AppCompatActivity {
    private LinearLayout navView;;
    private Button btnAddCategory;
    private TextView tvNameUser;
    private ImageButton btnMenu;
    private RelativeLayout containerCategory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        begin();

        this.btnAddCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addCategory();
            }
        });
    }

    private void addCategory() {
        // Crear un nuevo TextView (puedes personalizar según tus necesidades)
        TextView nuevoTextView = new TextView(this);
        nuevoTextView.setText("Nueva Categoría");

        // Establecer parámetros de diseño para el TextView
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );

        // Agregar el TextView al contenedorCategory con los parámetros de diseño
        containerCategory.addView(nuevoTextView, params);

        // Puedes realizar más acciones según tus necesidades después de agregar el elemento
        this.btnMenu.setOnClickListener(this::goMenu);
    }

    private void goMenu(View view) {
        Intent irNav= new Intent(getApplicationContext(), nav.class);
        startActivity(irNav);
    }

    private void begin(){
        this.btnAddCategory = findViewById(R.id.btnAddCategory);
        this.tvNameUser = findViewById(R.id.tvNameUser);
        this.containerCategory = findViewById(R.id.containerCategory);
        this.btnMenu = findViewById(R.id.btnMenu);
    }
}
